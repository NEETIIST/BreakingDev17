(function () {

/* Imports */
var Meteor = Package.meteor.Meteor;
var global = Package.meteor.global;
var meteorEnv = Package.meteor.meteorEnv;
var check = Package.check.check;
var Match = Package.check.Match;
var SimpleSchema = Package['aldeed:simple-schema'].SimpleSchema;
var MongoObject = Package['aldeed:simple-schema'].MongoObject;
var TAPi18next = Package['tap:i18n'].TAPi18next;
var TAPi18n = Package['tap:i18n'].TAPi18n;

/* Package-scope variables */
var __coffeescriptShare, SimpleSchemaTapi18n;

(function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/gildaspk_simpleschema-tapi18n-labels/packages/gildaspk_simpleschema-tapi18n-labels.js                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
(function () {

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// packages/gildaspk:simpleschema-tapi18n-labels/gildaspk:simpleschema-tapi18n-labels.coffee.js                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
__coffeescriptShare = typeof __coffeescriptShare === 'object' ? __coffeescriptShare : {}; var share = __coffeescriptShare;
var defaultLanguage;                     

SimpleSchema.extendOptions({
  i18nLabel: Match.Optional(String)
});

(function(originalLabel) {
  SimpleSchema.prototype.label = function(key) {
    var fieldDefinition, language, result;
    result = null;
    if (key === null) {
      return this.originalLabel();
    }
    fieldDefinition = this.getDefinition(key);
    if (fieldDefinition && fieldDefinition.i18nLabel) {
      language = SimpleSchemaTapi18n.getLanguage();
      result = TAPi18n.__(fieldDefinition.i18nLabel, {}, language);
    } else {
      result = originalLabel.apply(this, arguments);
    }
    return result;
  };
})(SimpleSchema.prototype.label);

defaultLanguage = Package["tap:i18n"].TAPi18n.translations[0];

SimpleSchemaTapi18n = {
  setDefaultLanguage: function(tag) {
    defaultLanguage = tag;
  },
  getLanguage: function() {
    var language, user, _ref;
    if (Meteor.isServer) {
      user = typeof Meteor.user === "function" ? Meteor.user() : void 0;
      language = (user != null ? (_ref = user.profile) != null ? _ref.language : void 0 : void 0) || defaultLanguage;
    }
    return language;
  }
};
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}).call(this);


/* Exports */
if (typeof Package === 'undefined') Package = {};
(function (pkg, symbols) {
  for (var s in symbols)
    (s in pkg) || (pkg[s] = symbols[s]);
})(Package['gildaspk:simpleschema-tapi18n-labels'] = {}, {
  SimpleSchemaTapi18n: SimpleSchemaTapi18n
});

})();
