var require = meteorInstall({"imports":{"api":{"contact":{"server":{"publications.js":["meteor/meteor","../contact.js",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// imports/api/contact/server/publications.js                                                       //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
var Meteor = void 0;                                                                                // 1
module.import('meteor/meteor', {                                                                    // 1
  "Meteor": function (v) {                                                                          // 1
    Meteor = v;                                                                                     // 1
  }                                                                                                 // 1
}, 0);                                                                                              // 1
var Contact = void 0;                                                                               // 1
module.import('../contact.js', {                                                                    // 1
  "Contact": function (v) {                                                                         // 1
    Contact = v;                                                                                    // 1
  }                                                                                                 // 1
}, 1);                                                                                              // 1
Meteor.publish('contact.all', function () {                                                         // 4
  return Contact.find();                                                                            // 5
});                                                                                                 // 6
//////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"contact.js":["meteor/mongo",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// imports/api/contact/contact.js                                                                   //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.export({                                                                                     // 1
  Contact: function () {                                                                            // 1
    return Contact;                                                                                 // 1
  }                                                                                                 // 1
});                                                                                                 // 1
var Mongo = void 0;                                                                                 // 1
module.import('meteor/mongo', {                                                                     // 1
  "Mongo": function (v) {                                                                           // 1
    Mongo = v;                                                                                      // 1
  }                                                                                                 // 1
}, 0);                                                                                              // 1
var Contact = new Mongo.Collection("contact");                                                      // 6
Contact.allow({                                                                                     // 8
  insert: function () {                                                                             // 9
    return true;                                                                                    // 10
  }                                                                                                 // 11
});                                                                                                 // 8
Contact.attachSchema(new SimpleSchema({                                                             // 14
  name: {                                                                                           // 15
    type: String,                                                                                   // 16
    label: "Nome"                                                                                   // 17
  },                                                                                                // 15
  company: {                                                                                        // 19
    type: String,                                                                                   // 20
    label: "Empresa"                                                                                // 21
  },                                                                                                // 19
  email: {                                                                                          // 23
    type: String,                                                                                   // 24
    regEx: SimpleSchema.RegEx.Email,                                                                // 25
    label: "Email"                                                                                  // 26
  }                                                                                                 // 23
}));                                                                                                // 14
//////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/check","./contact.js",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// imports/api/contact/methods.js                                                                   //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
var Meteor = void 0;                                                                                // 1
module.import('meteor/meteor', {                                                                    // 1
  "Meteor": function (v) {                                                                          // 1
    Meteor = v;                                                                                     // 1
  }                                                                                                 // 1
}, 0);                                                                                              // 1
var check = void 0;                                                                                 // 1
module.import('meteor/check', {                                                                     // 1
  "check": function (v) {                                                                           // 1
    check = v;                                                                                      // 1
  }                                                                                                 // 1
}, 1);                                                                                              // 1
var Contact = void 0;                                                                               // 1
module.import('./contact.js', {                                                                     // 1
  "Contact": function (v) {                                                                         // 1
    Contact = v;                                                                                    // 1
  }                                                                                                 // 1
}, 2);                                                                                              // 1
Meteor.methods({                                                                                    // 5
  'contact.insert': function (title, url) {                                                         // 6
    check(url, String);                                                                             // 7
    check(title, String);                                                                           // 8
    return Links.insert({                                                                           // 10
      url: url,                                                                                     // 11
      title: title,                                                                                 // 12
      createdAt: new Date()                                                                         // 13
    });                                                                                             // 10
  }                                                                                                 // 15
});                                                                                                 // 5
//////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"startup":{"both":{"index.js":["./validation_messages.js",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// imports/startup/both/index.js                                                                    //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.import('./validation_messages.js');                                                          // 1
//////////////////////////////////////////////////////////////////////////////////////////////////////

}],"validation_messages.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// imports/startup/both/validation_messages.js                                                      //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
// Custom validation messages -> Must be integrated with i18n                                       // 1
SimpleSchema.messages({                                                                             // 2
  required: "[label] é necessário",                                                                 // 3
  minString: "[label] must be at least [min] characters",                                           // 4
  maxString: "[label] cannot exceed [max] characters",                                              // 5
  minNumber: "[label] must be at least [min]",                                                      // 6
  maxNumber: "[label] cannot exceed [max]",                                                         // 7
  minDate: "[label] must be on or after [min]",                                                     // 8
  maxDate: "[label] cannot be after [max]",                                                         // 9
  badDate: "[label] is not a valid date",                                                           // 10
  minCount: "You must specify at least [minCount] values",                                          // 11
  maxCount: "You cannot specify more than [maxCount] values",                                       // 12
  noDecimal: "[label] must be an integer",                                                          // 13
  notAllowed: "[value] is not an allowed value",                                                    // 14
  expectedString: "[label] must be a string",                                                       // 15
  expectedNumber: "[label] must be a number",                                                       // 16
  expectedBoolean: "[label] must be a boolean",                                                     // 17
  expectedArray: "[label] must be an array",                                                        // 18
  expectedObject: "[label] must be an object",                                                      // 19
  expectedConstructor: "[label] must be a [type]",                                                  // 20
  regEx: [{                                                                                         // 21
    msg: "[label] failed regular expression validation"                                             // 22
  }, {                                                                                              // 22
    exp: SimpleSchema.RegEx.Email,                                                                  // 23
    msg: "[label] deve ser um endereço válido"                                                      // 23
  }, {                                                                                              // 23
    exp: SimpleSchema.RegEx.WeakEmail,                                                              // 24
    msg: "[label] must be a valid e-mail address"                                                   // 24
  }, {                                                                                              // 24
    exp: SimpleSchema.RegEx.Domain,                                                                 // 25
    msg: "[label] must be a valid domain"                                                           // 25
  }, {                                                                                              // 25
    exp: SimpleSchema.RegEx.WeakDomain,                                                             // 26
    msg: "[label] must be a valid domain"                                                           // 26
  }, {                                                                                              // 26
    exp: SimpleSchema.RegEx.IP,                                                                     // 27
    msg: "[label] must be a valid IPv4 or IPv6 address"                                             // 27
  }, {                                                                                              // 27
    exp: SimpleSchema.RegEx.IPv4,                                                                   // 28
    msg: "[label] must be a valid IPv4 address"                                                     // 28
  }, {                                                                                              // 28
    exp: SimpleSchema.RegEx.IPv6,                                                                   // 29
    msg: "[label] must be a valid IPv6 address"                                                     // 29
  }, {                                                                                              // 29
    exp: SimpleSchema.RegEx.Url,                                                                    // 30
    msg: "[label] must be a valid URL"                                                              // 30
  }, {                                                                                              // 30
    exp: SimpleSchema.RegEx.Id,                                                                     // 31
    msg: "[label] must be a valid alphanumeric ID"                                                  // 31
  }],                                                                                               // 31
  keyNotInSchema: "[key] is not allowed by the schema"                                              // 33
});                                                                                                 // 2
//////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"index.js":["./register-api.js","./mail-url.js",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// imports/startup/server/index.js                                                                  //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.import('./register-api.js');                                                                 // 1
module.import('./mail-url.js');                                                                     // 1
//////////////////////////////////////////////////////////////////////////////////////////////////////

}],"mail-url.js":["meteor/meteor",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// imports/startup/server/mail-url.js                                                               //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
var Meteor = void 0;                                                                                // 1
module.import('meteor/meteor', {                                                                    // 1
  "Meteor": function (v) {                                                                          // 1
    Meteor = v;                                                                                     // 1
  }                                                                                                 // 1
}, 0);                                                                                              // 1
var mgpass = Meteor.settings.mailGunPass;                                                           // 3
console.log(process.env.MAIL_URL);                                                                  // 5
process.env.MAIL_URL = "smtp://postmaster%40mg.breakingdev.pt:" + mgpass + "@smtp.mailgun.org:587";
console.log(mgpass);                                                                                // 9
console.log(Meteor.settings);                                                                       // 10
//////////////////////////////////////////////////////////////////////////////////////////////////////

}],"register-api.js":["../../api/contact/methods.js","../../api/contact/server/publications.js",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// imports/startup/server/register-api.js                                                           //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.import('../../api/contact/methods.js');                                                      // 1
module.import('../../api/contact/server/publications.js');                                          // 1
//////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}},"server":{"methods.js":function(){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// server/methods.js                                                                                //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
Meteor.methods({                                                                                    // 1
  sendEmail: function (doc) {                                                                       // 3
    check([doc.name, doc.company, doc.email], [String]);                                            // 5
    console.log(doc); // Let other method calls from the same client start running,                 // 7
    // without waiting for the email sending to complete.                                           // 10
                                                                                                    //
    this.unblock();                                                                                 // 11
    Email.send({                                                                                    // 13
      to: "neeti.isttagus@gmail.com",                                                               // 14
      from: doc.email,                                                                              // 15
      subject: "BreakingDev - " + doc.company                                                       // 16
    });                                                                                             // 13
  }                                                                                                 // 18
});                                                                                                 // 1
//////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":["/imports/startup/server","/imports/startup/both",function(require,exports,module){

//////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                  //
// server/main.js                                                                                   //
//                                                                                                  //
//////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                    //
module.import('/imports/startup/server');                                                           // 1
module.import('/imports/startup/both');                                                             // 1
//////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./server/methods.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
