var require = meteorInstall({"imports":{"api":{"contact":{"server":{"publications.js":["meteor/meteor","../contact.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/api/contact/server/publications.js                                                         //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var Meteor = void 0;                                                                                  // 1
module.import('meteor/meteor', {                                                                      // 1
  "Meteor": function (v) {                                                                            // 1
    Meteor = v;                                                                                       // 1
  }                                                                                                   // 1
}, 0);                                                                                                // 1
var Contact = void 0;                                                                                 // 1
module.import('../contact.js', {                                                                      // 1
  "Contact": function (v) {                                                                           // 1
    Contact = v;                                                                                      // 1
  }                                                                                                   // 1
}, 1);                                                                                                // 1
Meteor.publish('contact.all', function () {                                                           // 4
  return Contact.find();                                                                              // 5
});                                                                                                   // 6
////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"contact.js":["meteor/mongo",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/api/contact/contact.js                                                                     //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
module.export({                                                                                       // 1
  Contact: function () {                                                                              // 1
    return Contact;                                                                                   // 1
  }                                                                                                   // 1
});                                                                                                   // 1
var Mongo = void 0;                                                                                   // 1
module.import('meteor/mongo', {                                                                       // 1
  "Mongo": function (v) {                                                                             // 1
    Mongo = v;                                                                                        // 1
  }                                                                                                   // 1
}, 0);                                                                                                // 1
var Contact = new Mongo.Collection("contact");                                                        // 6
Contact.allow({                                                                                       // 8
  insert: function () {                                                                               // 9
    return true;                                                                                      // 10
  }                                                                                                   // 11
});                                                                                                   // 8
Contact.attachSchema(new SimpleSchema({                                                               // 14
  name: {                                                                                             // 15
    type: String,                                                                                     // 16
    label: "Name",                                                                                    // 17
    i18nLabel: 'home_sponsor_name'                                                                    // 18
  },                                                                                                  // 15
  company: {                                                                                          // 20
    type: String,                                                                                     // 21
    label: "Company",                                                                                 // 22
    i18nLabel: 'home_sponsor_company'                                                                 // 23
  },                                                                                                  // 20
  email: {                                                                                            // 25
    type: String,                                                                                     // 26
    regEx: SimpleSchema.RegEx.Email,                                                                  // 27
    label: "Email",                                                                                   // 28
    i18nLabel: 'home_sponsor_email'                                                                   // 29
  }                                                                                                   // 25
}));                                                                                                  // 14
////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/check","./contact.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/api/contact/methods.js                                                                     //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var Meteor = void 0;                                                                                  // 1
module.import('meteor/meteor', {                                                                      // 1
  "Meteor": function (v) {                                                                            // 1
    Meteor = v;                                                                                       // 1
  }                                                                                                   // 1
}, 0);                                                                                                // 1
var check = void 0;                                                                                   // 1
module.import('meteor/check', {                                                                       // 1
  "check": function (v) {                                                                             // 1
    check = v;                                                                                        // 1
  }                                                                                                   // 1
}, 1);                                                                                                // 1
var Contact = void 0;                                                                                 // 1
module.import('./contact.js', {                                                                       // 1
  "Contact": function (v) {                                                                           // 1
    Contact = v;                                                                                      // 1
  }                                                                                                   // 1
}, 2);                                                                                                // 1
Meteor.methods({                                                                                      // 5
  'contact.insert': function (title, url) {                                                           // 6
    check(url, String);                                                                               // 7
    check(title, String);                                                                             // 8
    return Links.insert({                                                                             // 10
      url: url,                                                                                       // 11
      title: title,                                                                                   // 12
      createdAt: new Date()                                                                           // 13
    });                                                                                               // 10
  }                                                                                                   // 15
});                                                                                                   // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"links":{"server":{"publications.js":["meteor/meteor","../links.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/api/links/server/publications.js                                                           //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var Meteor = void 0;                                                                                  // 1
module.import('meteor/meteor', {                                                                      // 1
  "Meteor": function (v) {                                                                            // 1
    Meteor = v;                                                                                       // 1
  }                                                                                                   // 1
}, 0);                                                                                                // 1
var Links = void 0;                                                                                   // 1
module.import('../links.js', {                                                                        // 1
  "Links": function (v) {                                                                             // 1
    Links = v;                                                                                        // 1
  }                                                                                                   // 1
}, 1);                                                                                                // 1
Meteor.publish('links.all', function () {                                                             // 4
  return Links.find();                                                                                // 5
});                                                                                                   // 6
////////////////////////////////////////////////////////////////////////////////////////////////////////

}]},"links.js":["meteor/mongo",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/api/links/links.js                                                                         //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
module.export({                                                                                       // 1
	Links: function () {                                                                                 // 1
		return Links;                                                                                       // 1
	}                                                                                                    // 1
});                                                                                                   // 1
var Mongo = void 0;                                                                                   // 1
module.import('meteor/mongo', {                                                                       // 1
	"Mongo": function (v) {                                                                              // 1
		Mongo = v;                                                                                          // 1
	}                                                                                                    // 1
}, 0);                                                                                                // 1
var Links = new Mongo.Collection("links");                                                            // 3
Links.allow({                                                                                         // 5
	insert: function () {                                                                                // 6
		return true;                                                                                        // 7
	}                                                                                                    // 8
});                                                                                                   // 5
Links.attachSchema(new SimpleSchema({                                                                 // 11
	name: {                                                                                              // 12
		type: String                                                                                        // 13
	},                                                                                                   // 12
	url: {                                                                                               // 15
		type: String                                                                                        // 16
	},                                                                                                   // 15
	isNavbar: {                                                                                          // 18
		type: Boolean                                                                                       // 19
	}                                                                                                    // 18
}));                                                                                                  // 11
////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"methods.js":["meteor/meteor","meteor/check","./links.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/api/links/methods.js                                                                       //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var Meteor = void 0;                                                                                  // 1
module.import('meteor/meteor', {                                                                      // 1
  "Meteor": function (v) {                                                                            // 1
    Meteor = v;                                                                                       // 1
  }                                                                                                   // 1
}, 0);                                                                                                // 1
var check = void 0;                                                                                   // 1
module.import('meteor/check', {                                                                       // 1
  "check": function (v) {                                                                             // 1
    check = v;                                                                                        // 1
  }                                                                                                   // 1
}, 1);                                                                                                // 1
var Links = void 0;                                                                                   // 1
module.import('./links.js', {                                                                         // 1
  "Links": function (v) {                                                                             // 1
    Links = v;                                                                                        // 1
  }                                                                                                   // 1
}, 2);                                                                                                // 1
Meteor.methods({                                                                                      // 5
  'links.insert': function (name, url) {                                                              // 6
    check(url, String);                                                                               // 7
    check(name, String);                                                                              // 8
    return Links.insert({                                                                             // 10
      name: name,                                                                                     // 11
      url: url                                                                                        // 12
    });                                                                                               // 10
  }                                                                                                   // 14
});                                                                                                   // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},"startup":{"both":{"index.js":["./validation_messages.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/startup/both/index.js                                                                      //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
module.import('./validation_messages.js');                                                            // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"validation_messages.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/startup/both/validation_messages.js                                                        //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
// Custom validation messages -> Must be integrated with i18n -> There isn't any solution to this yet
SimpleSchema.messages({                                                                               // 2
  required: "[label] é obrigatório / is required",                                                    // 3
  minString: "[label] must be at least [min] characters",                                             // 4
  maxString: "[label] cannot exceed [max] characters",                                                // 5
  minNumber: "[label] must be at least [min]",                                                        // 6
  maxNumber: "[label] cannot exceed [max]",                                                           // 7
  minDate: "[label] must be on or after [min]",                                                       // 8
  maxDate: "[label] cannot be after [max]",                                                           // 9
  badDate: "[label] is not a valid date",                                                             // 10
  minCount: "You must specify at least [minCount] values",                                            // 11
  maxCount: "You cannot specify more than [maxCount] values",                                         // 12
  noDecimal: "[label] must be an integer",                                                            // 13
  notAllowed: "[value] is not an allowed value",                                                      // 14
  expectedString: "[label] must be a string",                                                         // 15
  expectedNumber: "[label] must be a number",                                                         // 16
  expectedBoolean: "[label] must be a boolean",                                                       // 17
  expectedArray: "[label] must be an array",                                                          // 18
  expectedObject: "[label] must be an object",                                                        // 19
  expectedConstructor: "[label] must be a [type]",                                                    // 20
  regEx: [{                                                                                           // 21
    msg: "[label] failed regular expression validation"                                               // 22
  }, {                                                                                                // 22
    exp: SimpleSchema.RegEx.Email,                                                                    // 23
    msg: "[label] deve ser um endereço válido / must be a valid address"                              // 23
  }, {                                                                                                // 23
    exp: SimpleSchema.RegEx.WeakEmail,                                                                // 24
    msg: "[label] must be a valid e-mail address"                                                     // 24
  }, {                                                                                                // 24
    exp: SimpleSchema.RegEx.Domain,                                                                   // 25
    msg: "[label] must be a valid domain"                                                             // 25
  }, {                                                                                                // 25
    exp: SimpleSchema.RegEx.WeakDomain,                                                               // 26
    msg: "[label] must be a valid domain"                                                             // 26
  }, {                                                                                                // 26
    exp: SimpleSchema.RegEx.IP,                                                                       // 27
    msg: "[label] must be a valid IPv4 or IPv6 address"                                               // 27
  }, {                                                                                                // 27
    exp: SimpleSchema.RegEx.IPv4,                                                                     // 28
    msg: "[label] must be a valid IPv4 address"                                                       // 28
  }, {                                                                                                // 28
    exp: SimpleSchema.RegEx.IPv6,                                                                     // 29
    msg: "[label] must be a valid IPv6 address"                                                       // 29
  }, {                                                                                                // 29
    exp: SimpleSchema.RegEx.Url,                                                                      // 30
    msg: "[label] must be a valid URL"                                                                // 30
  }, {                                                                                                // 30
    exp: SimpleSchema.RegEx.Id,                                                                       // 31
    msg: "[label] must be a valid alphanumeric ID"                                                    // 31
  }],                                                                                                 // 31
  keyNotInSchema: "[key] is not allowed by the schema"                                                // 33
});                                                                                                   // 2
////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"index.js":["./links.js","./register-api.js","./mail-url.js","meteor/meteor",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/startup/server/index.js                                                                    //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
module.import('./links.js');                                                                          // 1
module.import('./register-api.js');                                                                   // 1
module.import('./mail-url.js');                                                                       // 1
var Meteor = void 0;                                                                                  // 1
module.import('meteor/meteor', {                                                                      // 1
    "Meteor": function (v) {                                                                          // 1
        Meteor = v;                                                                                   // 1
    }                                                                                                 // 1
}, 3);                                                                                                // 1
                                                                                                      //
// Use Prerender with your token                                                                      // 9
var prerenderio = Npm.require('prerender-node');                                                      // 10
                                                                                                      //
var settings = Meteor.settings.PrerenderIO;                                                           // 11
                                                                                                      //
if (settings && settings.token && settings.host) {                                                    // 13
    prerenderio.set('prerenderToken', settings.token);                                                // 14
    prerenderio.set('host', settings.host);                                                           // 15
    prerenderio.set('protocol', 'http');                                                              // 16
    WebApp.rawConnectHandlers.use(prerenderio);                                                       // 17
}                                                                                                     // 18
                                                                                                      //
;                                                                                                     // 18
////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"links.js":["meteor/meteor","../../api/links/links.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/startup/server/links.js                                                                    //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var Meteor = void 0;                                                                                  // 1
module.import('meteor/meteor', {                                                                      // 1
  "Meteor": function (v) {                                                                            // 1
    Meteor = v;                                                                                       // 1
  }                                                                                                   // 1
}, 0);                                                                                                // 1
var Links = void 0;                                                                                   // 1
module.import('../../api/links/links.js', {                                                           // 1
  "Links": function (v) {                                                                             // 1
    Links = v;                                                                                        // 1
  }                                                                                                   // 1
}, 1);                                                                                                // 1
Meteor.startup(function () {                                                                          // 8
  // if the Links collection is empty                                                                 // 9
  if (Links.find().count() === 0) {                                                                   // 10
    var data = [{                                                                                     // 11
      name: 'menu_index',                                                                             // 13
      url: '/',                                                                                       // 14
      isNavbar: true                                                                                  // 15
    }, {                                                                                              // 12
      name: 'menu_beasponsor',                                                                        // 18
      url: '/sponsor',                                                                                // 19
      isNavbar: true                                                                                  // 20
    }];                                                                                               // 17
    data.forEach(function (link) {                                                                    // 24
      return Links.insert(link);                                                                      // 24
    });                                                                                               // 24
  }                                                                                                   // 25
});                                                                                                   // 26
////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"mail-url.js":["meteor/meteor",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/startup/server/mail-url.js                                                                 //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var Meteor = void 0;                                                                                  // 1
module.import('meteor/meteor', {                                                                      // 1
  "Meteor": function (v) {                                                                            // 1
    Meteor = v;                                                                                       // 1
  }                                                                                                   // 1
}, 0);                                                                                                // 1
var mgpass = Meteor.settings.mailGunPass;                                                             // 3
process.env.MAIL_URL = "smtp://postmaster%40mg.breakingdev.pt:" + mgpass + "@smtp.mailgun.org:587";   // 5
////////////////////////////////////////////////////////////////////////////////////////////////////////

}],"register-api.js":["../../api/links/methods.js","../../api/links/server/publications.js","../../api/contact/methods.js","../../api/contact/server/publications.js",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// imports/startup/server/register-api.js                                                             //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
module.import('../../api/links/methods.js');                                                          // 1
module.import('../../api/links/server/publications.js');                                              // 1
module.import('../../api/contact/methods.js');                                                        // 1
module.import('../../api/contact/server/publications.js');                                            // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}}},"i18n":{"en.i18n.json":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// i18n/en.i18n.json                                                                                  //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n._enable({"helper_name":"_","supported_languages":null,"i18n_files_route":"/tap-i18n","preloaded_langs":[],"cdn_path":null});
TAPi18n.languages_names["en"] = ["English","English"];
// integrate the fallback language translations 
translations = {};
translations[namespace] = {"home_48hours":"48 hours of coding for college students from around the country","home_intro":"Lisbon's first university hackathon is back for a weekend you will not forget so soon.","home_photos":"We are setting up this year's website. Lots of exciting stuff coming up, but for now, take a look at the best pictures from last summer.","home_about_social":"Keep up to date with our social networks","home_about_email":"Or send us an email to","home_organization":"Organized by:","home_support":"With support from:","home_sponsor":"And sponsored by:","home_beasponsor":"Be a sponsor","home_github":"Source-code @ GitHub","home_tools":"Made with ","home_sponsor_intro":"A chance to be involved in projects made by students from the best portuguese universities.","home_sponsor_about":"Your company can be a part of BreakingDev. Join our sponsors to help make the best possible hackathon. One of our goals is also to join the best professionals in the industry with our contestants, for a one-of-a-kind hands-on experience.","home_sponsor_contact":"Fill our form below and we will get back at you as soon as possible.","home_sponsor_name":"Your name","home_sponsor_company":"Your company","home_sponsor_email":"You email address","home_sponsor_submit":"Submit","menu_index":"BreakingDev","menu_beasponsor":"Be a sponsor","lorem":"Lorem ipsum","lorem_ipsum":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."};
TAPi18n._loadLangFileObject("en", translations);
TAPi18n._registerServerTranslator("en", namespace);

////////////////////////////////////////////////////////////////////////////////////////////////////////

},"pt.i18n.json":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// i18n/pt.i18n.json                                                                                  //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
var _ = Package.underscore._,
    package_name = "project",
    namespace = "project";

if (package_name != "project") {
    namespace = TAPi18n.packages[package_name].namespace;
}
TAPi18n.languages_names["pt"] = ["Portuguese (Portugal)","Português"];
if(_.isUndefined(TAPi18n.translations["pt"])) {
  TAPi18n.translations["pt"] = {};
}

if(_.isUndefined(TAPi18n.translations["pt"][namespace])) {
  TAPi18n.translations["pt"][namespace] = {};
}

_.extend(TAPi18n.translations["pt"][namespace], {"home_48hours":"48 horas de programação para universitários de todo o país","home_intro":"O primeiro hackaton universitário de Lisboa está de volta para mais um fim-de-semana que não vais esquecer tão cedo.","home_photos":"Estamos a preparar o site da edição deste ano. Podes contar com muitas novidades, mas por enquanto, dá uma olhadela às melhores imagens do ultimo verão.","home_about_social":"Vai sabendo mais através das nossas redes sociais","home_about_email":"Ou envia-nos um email para ","home_organization":"Uma organização:","home_support":"Com o apoio:","home_sponsor":"E o patrocinio:","home_beasponsor":"Seja um patrocinador","home_github":"Source-code no Github","home_tools":"Feito com ","home_sponsor_intro":"Uma oportunidade de estar envolvido nos projetos dos alunos das melhores universidades do país.","home_sponsor_about":"A sua empresa pode participar no BreakingDev sendo um dos nossos patrocinadores. Um dos nossos objetivos passa por atrair ao evento profissionais da área para uma experiência única de contacto entre os alunos participantes, trabalhadores e empresas.","home_sponsor_contact":"Deixe o seu contacto em baixo e nós iremos entrar em contacto consigo o mais depressa possível.","home_sponsor_name":"O seu nome","home_sponsor_company":"A sua empresa","home_sponsor_email":"O seu contacto de email","home_sponsor_submit":"Submeter","menu_index":"BreakingDev","menu_beasponsor":"Seja um patrocinador","lorem":"Lorem ipsum","lorem_ipsum":"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."});
TAPi18n._registerServerTranslator("pt", namespace);

////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"server":{"methods.js":function(){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// server/methods.js                                                                                  //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
Meteor.methods({                                                                                      // 1
  sendEmail: function (doc) {                                                                         // 3
    check([doc.name, doc.company, doc.email], [String]);                                              // 5
    console.log(doc); // Let other method calls from the same client start running,                   // 7
    // without waiting for the email sending to complete.                                             // 10
                                                                                                      //
    this.unblock();                                                                                   // 11
    Email.send({                                                                                      // 13
      to: "neeti.isttagus@gmail.com",                                                                 // 14
      from: doc.email,                                                                                // 15
      subject: "BreakingDev - Informação sobre Patrocínio",                                           // 16
      text: "A empresa " + doc.company + " quer mais informação sobre os pacotes de patrocínio do BreakingDev. \n O contacto foi feito pelo/a Sr(a) " + doc.name + ", com o email: " + doc.email
    });                                                                                               // 13
  }                                                                                                   // 19
});                                                                                                   // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":["/imports/startup/server","/imports/startup/both",function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                    //
// server/main.js                                                                                     //
//                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                      //
module.import('/imports/startup/server');                                                             // 1
module.import('/imports/startup/both');                                                               // 1
////////////////////////////////////////////////////////////////////////////////////////////////////////

}]}},{"extensions":[".js",".json"]});
require("./i18n/en.i18n.json");
require("./i18n/pt.i18n.json");
require("./server/methods.js");
require("./server/main.js");
//# sourceMappingURL=app.js.map
